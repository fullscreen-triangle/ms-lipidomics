import collections
import os
import logging
import re
import pubchempy as pcp
import numpy as np
import requests
from matchms.metadata_utils import derive_fingerprint_from_smiles, derive_fingerprint_from_inchi, is_valid_inchikey
from matchms.typing import SpectrumType
from typing import List
import pandas as pd
from tqdm import tqdm
from gensim.models.basemodel import BaseTopicModel
from matchms.similarity import CosineGreedy, ModifiedCosine, PrecursorMzMatch
from spec2vec import SpectrumDocument
from spec2vec import Spec2Vec
from chembl_webresource_client.new_client import new_client
from Bio import SeqIO
from bs4 import BeautifulSoup
from tempfile import NamedTemporaryFile


def library_matching(documents_query: List[SpectrumDocument],
                     documents_library: List[SpectrumDocument],
                     model: BaseTopicModel,
                     presearch_based_on: List[str] = ["precursor_mz", "spec2vec-top10"],
                     ignore_non_annotated: bool = True,
                     include_scores=["spec2vec", "cosine", "modcosine"],
                     intensity_weighting_power: float = 0.5,
                     allowed_missing_percentage: float = 0,
                     cosine_tol: float = 0.005,
                     min_matches: int = 6,
                     mass_tolerance: float = 2.0,
                     mass_tolerance_type: str = "ppm"):
    found_matches = []
    m_mass_matches = None
    m_spec2vec_similarities = None
    m_modcos_similarities = None

    def get_metadata(documents):
        metadata = []
        for doc in documents:
            metadata.append(doc._obj.get("smiles"))
        return metadata

    library_spectra_metadata = get_metadata(documents_library)
    if ignore_non_annotated:
        # Get array of all ids for spectra with smiles
        library_ids = np.asarray([i for i, x in enumerate(library_spectra_metadata) if x])
    else:
        library_ids = np.arange(len(documents_library))

    allowed_presearch_type = ["precursor_mz", "spec2vec-top", "modcos-top"]
    msg = "Presearch must include one of: " + ", ".join(allowed_presearch_type)
    assert np.any([(x in y) for x in allowed_presearch_type for y in presearch_based_on]), msg

    # 1. Search for top-n Spec2Vec matches ------------------------------------
    if np.any(["spec2vec" in x for x in presearch_based_on]):
        top_n = int([x.split("top")[1] for x in presearch_based_on if "spec2vec" in x][0])
        print(f"Pre-selection includes spec2vec top {top_n}.")
        spec2vec = Spec2Vec(model=model, intensity_weighting_power=intensity_weighting_power,
                            allowed_missing_percentage=allowed_missing_percentage,
                            progress_bar=True)
        m_spec2vec_similarities = spec2vec.matrix([documents_library[i] for i in library_ids],
                                                  documents_query)

        # Select top_n similarity values:
        selection_spec2vec = np.argpartition(m_spec2vec_similarities, -top_n, axis=0)[-top_n:, :]
    else:
        selection_spec2vec = np.empty((0, len(documents_query)), dtype="int")

    # 2. Search for precursor_mz based matches ---------------------------------
    if "precursor_mz" in presearch_based_on:
        print(f"Pre-selection includes mass matches within {mass_tolerance} {mass_tolerance_type}.")
        mass_matching = PrecursorMzMatch(tolerance=mass_tolerance,
                                         tolerance_type=mass_tolerance_type)
        m_mass_matches = mass_matching.matrix([documents_library[i]._obj for i in library_ids],
                                              [x._obj for x in documents_query])
        selection_massmatch = []
        for i in range(len(documents_query)):
            selection_massmatch.append(np.where(m_mass_matches[:, i] == 1)[0])
    else:
        selection_massmatch = np.empty((len(documents_query), 0), dtype="int")

    # 3. Search for top-n modified cosine matches ------------------------------------
    if np.any(["modcos" in x for x in presearch_based_on]):
        top_n = int([x.split("top")[1] for x in presearch_based_on if "modcos" in x][0])
        print(f"Pre-selection includes modified cosine top {top_n}.")
        modcos = ModifiedCosine(tolerance=cosine_tol)

        n_rows = len(library_ids)
        n_cols = len(documents_query)
        m_modcos_similarities = np.zeros([n_rows, n_cols], dtype=np.float64)
        m_modcos_matches = np.zeros([n_rows, n_cols], dtype=np.float64)
        for i_ref, reference in enumerate(tqdm([documents_library[i]._obj for i in library_ids])):
            for i_query, query in enumerate([x._obj for x in documents_query]):
                score = modcos.pair(reference, query)
                m_modcos_similarities[i_ref][i_query] = score[0]
                m_modcos_matches[i_ref][i_query] = score[1]

        # Select top_n similarity values:
        m_modcos_selected = m_modcos_similarities.copy()
        m_modcos_selected[m_modcos_matches < min_matches] = 0
        selection_modcos = np.argpartition(m_modcos_selected, -top_n, axis=0)[-top_n:, :]
    else:
        selection_modcos = np.empty((0, len(documents_query)), dtype="int")

    # 4. Combine found matches ------------------------------------------------
    if "cosine" in include_scores:
        print("Calculate cosine score for selected candidates.")
    if "modcosine" in include_scores:
        print("Calculate modified cosine score for selected candidates.")

    for i in tqdm(range(len(documents_query))):
        s2v_top_ids = selection_spec2vec[:, i]
        mass_match_ids = selection_massmatch[i]
        modcos_ids = selection_modcos[:, i]

        all_match_ids = np.unique(np.concatenate((s2v_top_ids, mass_match_ids, modcos_ids)))

        if len(all_match_ids) > 0:
            if "cosine" in include_scores:
                # Get cosine score for found matches
                cosine_similarity = CosineGreedy(tolerance=cosine_tol)
                cosine_scores = []
                for match_id in library_ids[all_match_ids]:
                    cosine_scores.append(cosine_similarity.pair(documents_library[match_id]._obj,
                                                                documents_query[i]._obj))
            else:
                cosine_scores = len(all_match_ids) * ["not calculated"]

            if m_modcos_similarities is not None:
                mod_cosine_scores0 = [x for x in m_modcos_similarities[all_match_ids, i]]
                mod_cosine_scores1 = [x for x in m_modcos_matches[all_match_ids, i]]
                mod_cosine_scores = list(zip(mod_cosine_scores0, mod_cosine_scores1))
            elif "modcosine" in include_scores:
                # Get modified cosine score for found matches
                mod_cosine_similarity = ModifiedCosine(tolerance=cosine_tol)
                mod_cosine_scores = []
                for match_id in library_ids[all_match_ids]:
                    mod_cosine_scores.append(mod_cosine_similarity.pair(documents_library[match_id]._obj,
                                                                        documents_query[i]._obj))
            else:
                mod_cosine_scores = len(all_match_ids) * ["not calculated"]

            matches_df = pd.DataFrame({"cosine_score": [x["score"] for x in cosine_scores],
                                       "cosine_matches": [x["matches"] for x in cosine_scores],
                                       "mod_cosine_score": [x["score"] for x in mod_cosine_scores],
                                       "mod_cosine_matches": [x["matches"] for x in mod_cosine_scores]},
                                      index=library_ids[all_match_ids])

            if m_mass_matches is not None:
                matches_df["mass_match"] = m_mass_matches[all_match_ids, i]

            if m_spec2vec_similarities is not None:
                matches_df["s2v_score"] = m_spec2vec_similarities[all_match_ids, i]
            elif "spec2vec" in include_scores:
                spec2vec_similarity = Spec2Vec(model=model,
                                               intensity_weighting_power=intensity_weighting_power,
                                               allowed_missing_percentage=allowed_missing_percentage)
                spec2vec_scores = []
                for match_id in library_ids[all_match_ids]:
                    spec2vec_scores.append(spec2vec_similarity.pair(documents_library[match_id],
                                                                    documents_query[i]))
                matches_df["s2v_score"] = spec2vec_scores
            found_matches.append(matches_df.fillna(0))
        else:
            found_matches.append([])

    return found_matches


def pubchem_metadata_lookup(spectrum_in, name_search_depth=10, match_precursor_mz=False,
                            formula_search=False,
                            min_formula_length=6, formula_search_depth=25, verbose=1):
    if spectrum_in is None:
        return None

    spectrum = spectrum_in.clone()
    if is_valid_inchikey(spectrum.get("inchikey")):
        return spectrum

    def _plausible_name(compound_name):
        return (isinstance(compound_name, str) and len(compound_name) > 4)

    compound_name = spectrum.get("compound_name")
    if not _plausible_name(compound_name):
        return spectrum

    # Start pubchem search
    inchi = spectrum.get("inchi")
    parent_mass = spectrum.get("parent_mass")
    if isinstance(parent_mass, np.ndarray):
        parent_mass = parent_mass[0]
    formula = spectrum.get("formula")

    # 1) Search for matching compound name
    results_pubchem = pubchem_name_search(compound_name, name_search_depth=name_search_depth,
                                          verbose=verbose)

    if len(results_pubchem) > 0:

        # 1a) Search for matching inchi
        if likely_has_inchi(inchi):
            inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_inchi_match(results_pubchem, inchi,
                                                                                       verbose=verbose)
        # 1b) Search for matching parent mass
        if not likely_has_inchi(inchi) or inchikey_pubchem is None:
            inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_mass_match(results_pubchem,
                                                                                      parent_mass,
                                                                                      given_mass="parent mass",
                                                                                      verbose=verbose)

        # 1c) Search for matching precursor mass (optional)
        if match_precursor_mz and inchikey_pubchem is None:
            precursor_mz = spectrum.get("precursor_mz")
            inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_mass_match(results_pubchem,
                                                                                      precursor_mz,
                                                                                      given_mass="precursor mass",
                                                                                      verbose=verbose)

        if inchikey_pubchem is not None and inchi_pubchem is not None:
            logging.info("Matching compound name: %s", compound_name)
            if verbose >= 1:
                print(f"Matching compound name: {compound_name}")
            spectrum.set("inchikey", inchikey_pubchem)
            spectrum.set("inchi", inchi_pubchem)
            spectrum.set("smiles", smiles_pubchem)
            return spectrum

        if verbose >= 2:
            print(f"No matches found for compound name: {compound_name}")

    # 2) Search for matching formula
    if formula_search and formula and len(formula) >= min_formula_length:
        results_pubchem = pubchem_formula_search(formula, formula_search_depth=formula_search_depth,
                                                 verbose=verbose)

        if len(results_pubchem) > 0:

            # 2a) Search for matching inchi
            if likely_has_inchi(inchi):
                inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_inchi_match(results_pubchem, inchi,
                                                                                           verbose=verbose)
            # 2b) Search for matching parent mass
            if inchikey_pubchem is None:
                inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_mass_match(results_pubchem,
                                                                                          parent_mass,
                                                                                          given_mass="parent mass",
                                                                                          verbose=verbose)
            # 2c) Search for matching precursor mass (optional)
            if match_precursor_mz and inchikey_pubchem is None:
                precursor_mz = spectrum.get("precursor_mz")
                inchi_pubchem, inchikey_pubchem, smiles_pubchem = find_pubchem_mass_match(results_pubchem,
                                                                                          precursor_mz,
                                                                                          given_mass="precursor mass",
                                                                                          verbose=verbose)
            if inchikey_pubchem is not None and inchi_pubchem is not None:
                logging.info("Matching formula: %s", formula)
                if verbose >= 1:
                    print(f"Matching formula: {formula}")
                spectrum.set("inchikey", inchikey_pubchem)
                spectrum.set("inchi", inchi_pubchem)
                spectrum.set("smiles", smiles_pubchem)
                return spectrum

            if verbose >= 2:
                print(f"No matches found for formula: {formula}")

    return spectrum


def likely_has_inchi(inchi):
    """Quick test to avoid excess in-depth testing"""
    if inchi is None:
        return False
    inchi = inchi.strip('"')
    regexp = r"(InChI=1|1)(S\/|\/)[0-9, A-Z, a-z,\.]{2,}\/(c|h)[0-9]"
    if not re.search(regexp, inchi):
        return False
    return True


def likely_inchi_match(inchi_1, inchi_2, min_agreement=3):
    if min_agreement < 2:
        print("Warning! 'min_agreement' < 2 has no discriminative power. Should be => 2.")
    if min_agreement == 2:
        print("Warning! 'min_agreement' == 2 has little discriminative power",
              "(only looking at structure formula. Better use > 2.")
    agreement = 0
    ignore_lst = ['"', ' ', '-', '+', '?']
    for ignore in ignore_lst:
        inchi_1 = inchi_1.replace(ignore, '')
        inchi_2 = inchi_2.replace(ignore, '')
    inchi_1_parts = inchi_1.split('/')
    inchi_2_parts = inchi_2.split('/')
    if len(inchi_1_parts) >= min_agreement and len(
            inchi_2_parts) >= min_agreement:
        # Count how many parts agree well
        for i in range(min_agreement):
            agreement += (inchi_1_parts[i] == inchi_2_parts[i])

    return bool(agreement == min_agreement)


def likely_inchikey_match(inchikey_1, inchikey_2, min_agreement=1):
    if min_agreement not in [1, 2, 3]:
        print("Warning! 'min_agreement' should be 1, 2, or 3.")
    agreement = 0
    inchikey_1 = inchikey_1.upper().replace('"', '').replace(' ', '')
    inchikey_2 = inchikey_2.upper().replace('"', '').replace(' ', '')
    inchikey_1_parts = inchikey_1.split('-')
    inchikey_2_parts = inchikey_2.split('-')
    if len(inchikey_1_parts) >= min_agreement and len(
            inchikey_2_parts) >= min_agreement:
        # Count how many parts mostly agree
        for i in range(min_agreement):
            agreement += (inchikey_1_parts[i] == inchikey_2_parts[i])

    return agreement == min_agreement


def pubchem_name_search(compound_name: str, name_search_depth=10, verbose=1):
    """Search pubmed for compound name"""
    results_pubchem = pcp.get_compounds(compound_name,
                                        'name',
                                        listkey_count=name_search_depth)
    if verbose >= 2:
        print("Found at least", len(results_pubchem),
              "compounds of that name on pubchem.")
    return results_pubchem


def pubchem_formula_search(compound_formula: str, formula_search_depth=25, verbose=1):
    """Search pubmed for compound formula"""
    sids_pubchem = pcp.get_sids(compound_formula,
                                'formula',
                                listkey_count=formula_search_depth)

    results_pubchem = []
    for sid in sids_pubchem:
        result = pcp.Compound.from_cid(sid['CID'])
        results_pubchem.append(result)

    if verbose >= 2:
        print(f"Found at least {len(results_pubchem)} compounds of with formula: {compound_formula}.")
    return results_pubchem


def find_pubchem_inchi_match(results_pubchem,
                             inchi,
                             min_inchi_match=3,
                             verbose=1):
    inchi_pubchem = None
    inchikey_pubchem = None
    smiles_pubchem = None

    # Loop through first 'name_search_depth' results found on pubchem. Stop once first match is found.
    for result in results_pubchem:
        inchi_pubchem = '"' + result.inchi + '"'
        inchikey_pubchem = result.inchikey
        smiles_pubchem = result.isomeric_smiles
        if smiles_pubchem is None:
            smiles_pubchem = result.canonical_smiles

        match_inchi = likely_inchi_match(inchi, inchi_pubchem,
                                         min_agreement=min_inchi_match)

        if match_inchi:
            logging.info("Matching inchi: %s", inchi)
            if verbose >= 1:
                print(f"Found matching compound for inchi: {inchi} (Pubchem: {inchi_pubchem}")
            break

    if not match_inchi:
        inchi_pubchem = None
        inchikey_pubchem = None
        smiles_pubchem = None

        if verbose >= 2:
            print("No matches found for inchi", inchi, "\n")

    return inchi_pubchem, inchikey_pubchem, smiles_pubchem


def find_pubchem_mass_match(results_pubchem,
                            parent_mass,
                            mass_tolerance=2.0,
                            given_mass="parent mass",
                            verbose=1):
    inchi_pubchem = None
    inchikey_pubchem = None
    smiles_pubchem = None

    for result in results_pubchem:
        inchi_pubchem = '"' + result.inchi + '"'
        inchikey_pubchem = result.inchikey
        smiles_pubchem = result.isomeric_smiles
        if smiles_pubchem is None:
            smiles_pubchem = result.canonical_smiles

        pubchem_mass = float(results_pubchem[0].exact_mass)
        match_mass = (np.abs(pubchem_mass - parent_mass) <= mass_tolerance)

        if match_mass:
            logging.info("Matching molecular weight %s vs parent mass of %s",
                         str(np.round(pubchem_mass, 1)),
                         str(np.round(parent_mass, 1)))
            if verbose >= 1:
                print(f"Matching molecular weight ({pubchem_mass:.1f} vs {given_mass} of {parent_mass:.1f})")
            break

    if not match_mass:
        inchi_pubchem = None
        inchikey_pubchem = None
        smiles_pubchem = None

        if verbose >= 2:
            print(f"No matches found for mass {parent_mass} Da")

    return inchi_pubchem, inchikey_pubchem, smiles_pubchem


def add_fingerprint(spectrum_in: SpectrumType, fingerprint_type: str = "daylight",
                    nbits: int = 2048) -> SpectrumType:
    if spectrum_in is None:
        return None

    spectrum = spectrum_in.clone()

    # First try to get fingerprint from smiles
    if spectrum.get("smiles", None):
        fingerprint = derive_fingerprint_from_smiles(spectrum.get("smiles"),
                                                     fingerprint_type, nbits)
        if isinstance(fingerprint, np.ndarray) and fingerprint.sum() > 0:
            spectrum.set("fingerprint", fingerprint)
            return spectrum

    # Second try to get fingerprint from inchi
    if spectrum.get("inchi", None):
        fingerprint = derive_fingerprint_from_inchi(spectrum.get("inchi"),
                                                    fingerprint_type, nbits)
        if isinstance(fingerprint, np.ndarray) and fingerprint.sum() > 0:
            spectrum.set("fingerprint", fingerprint)
            return spectrum

    return spectrum


def fetch_compounds_ChEMBL(smiles_list):
    compounds_api = new_client.molecule
    compounds_provider = compounds_api.filter(
        molecule_chembl_id__in=list(smiles_list)).only("molecule_chembl_id", "molecule_structures", "target_organism",
                                                       "activity_id")
    compounds_df = pd.DataFrame.from_records(smiles_list, )
    compounds_df = compounds_df.dropna(axis=0, how="any", inplace=True)
    compounds_df = compounds_df.drop_duplicates("molecule_chembl_id", keep="first", inplace=True)
    canonical_smiles = []
    for i, compounds in compounds_df.iterrows():
        try:
            canonical_smiles.append(compounds["molecule_structures"]["canonical_smiles"])
        except KeyError:
            canonical_smiles.append(None)

    compounds_df["smiles"] = canonical_smiles
    compounds_df.drop("molecule_structures", axis=1, inplace=True)


def uniprotSequence(uniprot_id):
    r = requests.get("https://www.uniprot.org/uniprot/{0}.fasta".format(uniprot_id))
    r.raise_for_status()
    with NamedTemporaryFile(suffix=".fasta", mode="w", delete=False) as tmp:
        tmp.write(r.text)
    sequence = SeqIO.read(tmp.name, format="fasta")

    # Delete temporary file now that we have read it
    os.remove(tmp.name)

    print(sequence.description)
    print(sequence.seq)
    return sequence


def kinaseTargets(kgroup):
    response = requests.get("https://klifs.net/api/kinase_families", params={"kinase_group": str(kgroup)})
    result = response.json()

    def getKinaseInformation(kinase_ID):
        response = requests.get("https://klifs.net/api/kinase_information", params={"kinase_ID": 22})
        response.raise_for_status()
        result = response.json()
        return result


def wikipediaArticles(page_name):
    r = requests.get("https://en.wikipedia.org/wiki/{}".format(page_name))
    r.raise_for_status()
    html = BeautifulSoup(r.text)
    header = html.find("span", id="General_chemical_properties")
    table = header.find_all_next()[4]
    table_body = table.find("tbody")

    data = []
    for row in table_body.find_all("tr"):
        cells = row.find_all("td")
        if cells:
            data.append([])
        for cell in cells:
            cell_content = cell.text.strip()
            try:  # convert to float if possible
                cell_content = float(cell_content)
            except ValueError:
                pass
            data[-1].append(cell_content)

    # Empty fields are denoted with "?" which casts respective columns to object types
    # (here mix of strings and floats) but we want float64, therefore replace "?" with NaN values
    pd.DataFrame.from_records(data).replace("?", np.nan)


