import glob
import math
import multiprocessing
from multiprocessing import Pool
import os
import sys
from sys import platform
import re
import time
import pandas as pd
import configparser
from typing import Tuple, Union
from numpy import int64

from polytomia.LipidComposer import LipidComposer
from polytomia.PrecursorHunter import PrecursorHunter
from polytomia.SpectraReader import extract_mzml, get_xic_from_pl
from polytomia.utils import save_output


def searchLipids(param_dct):
    start_time = time.clock()
    lipidcomposer = LipidComposer()

    usr_lipid_class = param_dct["lipid_class"]
    usr_charge = param_dct["charge_mode"]
    usr_vendor = param_dct["vendor"]
    usr_fa_xlsx = param_dct["fawhitelist_path_str"]
    usr_mzml = param_dct["mzml_path_str"]
    output_folder = param_dct["img_output_folder_str"]
    output_sum_xlsx = param_dct["xlsx_output_path_str"]
    usr_rt_range = [param_dct["rt_start"], param_dct["rt_end"]]
    # usr_pr_mz_range = [param_dct['mz_start'], param_dct['mz_end']]
    mz_start = param_dct["mz_start"]
    mz_end = param_dct["mz_end"]
    usr_dda_top = param_dct["dda_top"]
    usr_ms1_threshold = param_dct["ms_th"]
    usr_ms1_max = param_dct["ms_max"]
    usr_ms1_ppm = param_dct["ms_ppm"]
    usr_ms1_precision = usr_ms1_ppm * 1e-6
    # usr_rank_score_filter = param_dct['rank_score_filter']
    # usr_score_filter = param_dct['score_filter']
    # usr_isotope_score_filter = param_dct['isotope_score_filter']
    # usr_ms2_info_th = param_dct['ms2_infopeak_threshold']
    # usr_rank_mode = param_dct['rank_score']
    # usr_fast_isotope = param_dct['fast_isotope']
    if "xic_ppm" in list(param_dct.keys()):
        usr_xic_ppm = int(param_dct["xic_ppm"])
    else:
        usr_xic_ppm = usr_ms1_ppm

    # parameters from settings tab
    usr_core_num = param_dct["core_number"]
    usr_max_ram = param_dct["max_ram"]

    # usr_dpi = param_dct['img_dpi']
    # usr_img_type = param_dct['img_type']

    hunter_start_time_str = param_dct["hunter_start_time"]

    try:
        if param_dct["debug_mode"] == "ON":
            save_session = True
        else:
            pass
    except (KeyError, AttributeError):
        print("Debug mode == off")

    # Check platform for multiprocessing settings

    if platform == "linux" or platform == "linux2":  # linux
        if usr_core_num > 1:
            os_typ = "linux_multi"
            print(
                "[INFO] --> LipidHunter Running on >>> Linux with multiprocessing mode ..."
            )
        else:
            os_typ = "linux_single"
            print(
                "[INFO] --> LipidHunter Running on >>> Linux with single core mode ..."
            )
    elif platform == "win32":  # Windows
        os_typ = "windows"
        print("[INFO] --> LipidHunter Running on >>> Windows ...")
    elif platform == "darwin":  # macOS
        if usr_core_num > 1:
            os_typ = "linux_multi"
            print(
                "[INFO] --> LipidHunter Running on >>> macOS with multiprocessing mode ..."
            )
        else:
            os_typ = "linux_single"
            print(
                "[INFO] --> LipidHunter Running on >>> macOS with single core mode ..."
            )
    else:
        usr_core_num = 1
        param_dct["core_number"] = 1
        os_typ = "linux_single"
        print(
            "[INFO] --> LipidHunter Running on >>> unoptimized system ... %s" % platform
        )
        print("[WARNING] !!! Force to use single core mode !!")

    print("[INFO] --> Start to process >>>")
    print("[INFO] --> Lipid class: %s >>>" % usr_lipid_class)

    composer_param_dct = {
        "fa_whitelist": usr_fa_xlsx,
        "lipid_class": usr_lipid_class,
        "charge_mode": usr_charge,
        "exact_position": "FALSE",
    }

    t_lm_0 = time.time()
    usr_lipid_master_df = lipidcomposer.compose_lipid(
        param_dct=composer_param_dct, ms2_ppm=50)
    print(
        "[INFO] --> Lipid Master Table generated >>> in %.2f sec"
        % (time.time() - t_lm_0)
    )
    log_master_name = "Lipid_Master_%s.csv" % hunter_start_time_str
    log_master_name = os.path.join(output_folder, log_master_name)
    save_output(
        log_master_name, usr_lipid_master_df, output_name="Lipid Master table"
    )
    lipid_info_df = (
        usr_lipid_master_df
    )

    pos_charge_lst = ["[M+H]+", "[M+Na]+", "[M+NH4]+"]
    neg_charge_lst = ["[M-H]-", "[M+HCOO]-", "[M+CH3COO]-"]
    if usr_charge in neg_charge_lst:
        if usr_lipid_class in ["PC", "LPC"]:
            if usr_charge == "[M+HCOO]-":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+HCOO]-_MZ"])
                    & (lipid_info_df["[M+HCOO]-_MZ"] <= mz_end)
                    ]
            elif usr_charge == "[M+CH3COO]-":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+CH3COO]-_MZ"])
                    & (lipid_info_df["[M+CH3COO]-_MZ"] <= mz_end)
                    ]
            else:
                print(
                    "PC charge not supported.  User input charge = %s. "
                    "LipidHunter support [M+HCOO]- and [M+CH3COO]-." % usr_charge
                )
        else:
            lipid_info_df = lipid_info_df[
                (mz_start <= lipid_info_df["[M-H]-_MZ"])
                & (lipid_info_df["[M-H]-_MZ"] <= mz_end)
                ]
    elif usr_charge in pos_charge_lst:
        if usr_lipid_class == "TG":
            if usr_charge == "[M+NH4]+":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+NH4]+_MZ"])
                    & (lipid_info_df["[M+NH4]+_MZ"] <= mz_end)
                    ]
            elif usr_charge == "[M+H]+":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+H]+_MZ"])
                    & (lipid_info_df["[M+H]+_MZ"] <= mz_end)
                    ]
            elif usr_charge == "[M+Na]+":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+Na]+_MZ"])
                    & (lipid_info_df["[M+Na]+_MZ"] <= mz_end)
                    ]
        if usr_lipid_class == "DG":
            if usr_charge == "[M+NH4]+":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+NH4]+_MZ"])
                    & (lipid_info_df["[M+NH4]+_MZ"] <= mz_end)
                    ]
            elif usr_charge == "[M+H]+":
                lipid_info_df = lipid_info_df[
                    (mz_start <= lipid_info_df["[M+H]+_MZ"])
                    & (lipid_info_df["[M+H]+_MZ"] <= mz_end)
                    ]
    else:
        print(
            "Lipid class or charge NOT supported.  User input lipid class = %s, charge = %s. "
            % (usr_lipid_class, usr_charge)
        )

    # TODO(zhixu.ni@uni-leipzig.de): Add more error to the error_lst.

    pr_hunter = PrecursorHunter(lipid_info_df, param_dct, os_type=os_typ)

    output_df = pd.DataFrame()
    if os.path.isfile(usr_mzml):
        print("[STATUS] >>> Start to process file: %s" % usr_mzml)
    else:
        print("[ERROR] !!! FileNotFoundError: %s" % usr_mzml)
        print("[ERROR] !!! FileNotFoundError: %s" % usr_mzml)
        return False, False, False

    usr_scan_info_df, usr_spectra_pl, ms1_xic_df = extract_mzml(
        usr_mzml,
        usr_rt_range,
        dda_top=usr_dda_top,
        ms1_threshold=usr_ms1_threshold,
        ms1_precision=usr_ms1_precision,
        vendor=usr_vendor,
        ms1_max=usr_ms1_max,
    )

    print("[INFO] --> MS1_XIC_df.shape", ms1_xic_df.shape)
    # Find all possible precursor according to lipid master table
    ms1_obs_pr_df = pr_hunter.get_matched_pr(
        usr_scan_info_df,
        usr_spectra_pl,
        ms1_max=usr_ms1_max,
        core_num=usr_core_num,
        max_ram=usr_max_ram,
    )

    if ms1_obs_pr_df is False:
        print("[WARNING] !!! NO suitable precursor --> Check settings!!\n")
        print("[WARNING] !! NO suitable precursor --> Check settings!!\n")
        return False, False, False

    print("[INFO] --> ms1 precursor matched")

    # Remove bad precursors, keep the matched scans by DDA_rank and scan number
    # Build unique str identifier for each scan with scan_number00dda_rank use numpy.int64 to avoid large scan_number
    # The unique identifier is important to index scans
    usr_scan_info_df["scan_checker"] = (
        usr_scan_info_df["scan_number"]
            .astype(int64)
            .astype(str)
            .str.cat(usr_scan_info_df["DDA_rank"].astype(int64).astype(str), sep="_")
    )
    ms1_obs_pr_df["scan_checker"] = (
        ms1_obs_pr_df["scan_number"]
            .astype(int64)
            .astype(str)
            .str.cat(
            ms1_obs_pr_df["DDA_rank"].astype(int64).astype(str).astype(str), sep="_"
        )
    )

    checked_info_df = ms1_obs_pr_df[
        ms1_obs_pr_df["scan_checker"].isin(usr_scan_info_df["scan_checker"].tolist())
    ].copy()
    checked_info_df.sort_values(
        by=["scan_checker", "Lib_mz"], ascending=[True, True], inplace=True
    )

    # # reserved for further debug_mode options
    # if 'debug_mode' in list(param_dct.keys()):
    #     if param_dct['debug_mode'] == 'ON':
    #         usr_scan_info_df.to_csv(os.path.join(output_folder, 'usr_scan_info.csv'))
    #         ms1_obs_pr_df.to_csv(os.path.join(output_folder, 'ms1_obs_pr_df.csv'))
    #         checked_info_df.to_csv(os.path.join(output_folder, 'checked_info_df.csv'))

    if checked_info_df.empty:
        print("[ERROR] !!! No identification in pre-match steps !!")
        print("!! No identification in pre-match steps !!\n")
        return False, False, False
    else:
        print(
            "[INFO] --> features identified in the pre-match: ",
            checked_info_df.shape[0],
        )

    ms1_xic_mz_lst = sorted(set(ms1_obs_pr_df["MS1_XIC_mz"].values.tolist()))
    print("ms1_xic_mz_lst", len(ms1_xic_mz_lst))
    print(ms1_xic_mz_lst)
    print("[INFO] --> Start to extract XIC")

    # Distribute task according to core numbers
    if len(ms1_xic_mz_lst) >= 3 * usr_core_num:
        sub_len = int(math.ceil(len(ms1_xic_mz_lst) / usr_core_num))
        core_key_list = [
            ms1_xic_mz_lst[k: k + sub_len]
            for k in range(0, len(ms1_xic_mz_lst), sub_len)
        ]
    else:
        core_key_list = [ms1_xic_mz_lst]

    # Start multiprocessing to get XIC according to precursor m/z found above
    print(
        "[STATUS] >>> Start multiprocessing to get XIC ==> ==> ==> Number of Cores: %i"
        % usr_core_num
    )
    xic_dct = {}

    if usr_core_num > 1:
        xic_results_lst = []

        if os_typ == "windows":
            parallel_pool = Pool(usr_core_num)
            queue = ""
            worker_count = 1
            for core_list in core_key_list:
                if isinstance(core_list, tuple) or isinstance(core_list, list):
                    if None in core_list:
                        core_list = [x for x in core_list if x is not None]
                    else:
                        pass
                    print(
                        "[STATUS] >>> Core #%i ==> ...... processing ......"
                        % worker_count
                    )
                    print(core_list)
                    # TODO (georgia.angelidou@uni-leipzig.de): maybe can be combine or stay like this????
                    xic_result = parallel_pool.apply_async(
                        get_xic_from_pl,
                        args=(core_list, ms1_xic_df, usr_xic_ppm, os_typ, queue),
                    )
                    worker_count += 1
                    xic_results_lst.append(xic_result)

            parallel_pool.close()
            parallel_pool.join()
            # del ms1_xic_df
            # TODO (georgia.angelidou@uni-leipzig.de): can be done before the join??????
            for xic_result in xic_results_lst:
                try:
                    sub_xic_dct = xic_result.get()
                    if len(list(sub_xic_dct.keys())) > 0:
                        xic_dct.update(sub_xic_dct)

                except (KeyError, SystemError, ValueError):
                    pass
            del xic_results_lst

        else:  # for linux
            jobs = []
            queue = multiprocessing.Queue()
            worker_count = 1
            for core_list in core_key_list:
                if isinstance(core_list, tuple) or isinstance(core_list, list):
                    if None in core_list:
                        core_list = [x for x in core_list if x is not None]
                    else:
                        pass
                    print(
                        "[STATUS] >>> Core #%i ==> ...... processing ......"
                        % worker_count
                    )
                    print(core_list)
                    job = multiprocessing.Process(
                        target=get_xic_from_pl,
                        args=(core_list, ms1_xic_df, usr_xic_ppm, os_typ, queue),
                    )
                    worker_count += 1
                    jobs.append(job)
                    job.start()
                    xic_results_lst.append(queue.get())
            del ms1_xic_df

            for j in jobs:
                j.join()

            # TODO (georgia,angelidou@uni-leipzig.de):
            #  question does these part can be move before the different jobs are join?????
            for xic_result in xic_results_lst:
                try:
                    if len(list(xic_result.keys())) > 0:
                        xic_dct.update(xic_result)
                except (KeyError, SystemError, ValueError):
                    pass
            del xic_results_lst
    else:
        print("[INFO] --> Using single core mode...")
        queue = ""
        worker_count = 1
        for core_list in core_key_list:
            if isinstance(core_list, tuple) or isinstance(core_list, list):
                if None in core_list:
                    core_list = [x for x in core_list if x is not None]
                else:
                    pass
                print(
                    "[STATUS] >>> Core #1 Part %i ==> ...... processing ......"
                    % worker_count
                )
                print(core_list)
                sub_xic_dct = get_xic_from_pl(
                    core_list, ms1_xic_df, usr_xic_ppm, os_typ, queue
                )
                worker_count += 1

                if len(list(sub_xic_dct.keys())) > 0:
                    xic_dct.update(sub_xic_dct)
        del ms1_xic_df

    if len(list(xic_dct.keys())) == 0:
        print("[ERROR] !!! No precursor for XIC found !!")
        print("!! No precursor for XIC found !!\n")
        return False, False, False
    else:
        print("[INFO] --> Number of XIC extracted: %i" % len(list(xic_dct.keys())))

    print("[STATUS] >>> Start to Hunt for Lipids !!")
