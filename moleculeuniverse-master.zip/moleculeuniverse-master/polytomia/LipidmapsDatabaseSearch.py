import os
import requests
import warnings
import numpy as np
import pandas as pd
from requests_toolbelt.multipart.encoder import MultipartEncoder

from polytomia.ParallelFunc import pr_window_calc_para, ppm_window_para

try:
    from StringIO import StringIO
except ImportError:
    from io import StringIO

warnings.simplefilter(action='ignore', category=FutureWarning)
pd.options.mode.chained_assignment = None
LIPIDMAPS_URL = 'http://lipidmaps-dev.babraham.ac.uk/tools/ms/py_bulk_search.php'
BATCH_SIZE = 500


def bulk_structure_search(data, params):
    mzList = data['mz'].unique().tolist()
    numMZ = len(mzList)
    targetAdducts = params['adducts']
    targetAdducts = [x[x.find('[') + 1: x.find(']')] for x in targetAdducts]
    targetAdducts = ','.join(targetAdducts)
    matches = pd.DataFrame()
    increment = 63.0 / np.ceil(float(numMZ) / BATCH_SIZE)
    for start in range(0, numMZ, BATCH_SIZE):
        mzBatch = mzList[start: start + BATCH_SIZE]
        # Get a string with one m/z per line (text file alike)
        mzStr = os.linesep.join(map(str, mzBatch))
        tolerance = mzBatch[-1] * (4.0 / 1e6)
        categories = ["Fatty Acyls [FA]", "Glycerolipids [GL]", "Glycerophospholipids [GP]", "Sphingolipids [SP]",
                      "Sterol Lipids [ST]", "Prenol Lipids [PR]",
                      "Saccharolipids [SL]", "Polyketides [PK]"]
        mpData = MultipartEncoder(
            fields={'CHOICE': 'COMP_DB', 'sort': 'DELTA',
                    'file': ('file', StringIO(mzStr), 'text/plain'),
                    'tol': str(tolerance), 'ion': targetAdducts,
                    'even': '1',
                    'category': ','.join(categories)})

        response = requests.post(LIPIDMAPS_URL, data=mpData, headers={'Content-Type': mpData.content_type})
        batchMatches = pd.read_csv(StringIO(response.text), sep='\t',
                                   engine='python', index_col=False)
        matches = matches.append(batchMatches, ignore_index=True)
    matches['Input Mass'] = matches['Input Mass'].apply(round, ndigits=6)
    # Calculate the delta PPM of each row and add it to the dataframe
    dPPM = abs(matches['Input Mass'] - matches['Matched MZ']) * 1e6 / matches['Input Mass']
    matches.insert(2, 'Delta_PPM', dPPM)
    matches.insert(3, 'rt', 0.0)
    matches.insert(4, 'Polarity', '')
    # Calculate progress increment for each batch
    increment = 33.0 / np.ceil(len(data) / float(BATCH_SIZE))
    # Create result dataframe with all the columns in that dataframe
    colNames = [x for x in list(data) if x not in ['', 'rt', 'Polarity']]
    extraCols = []
    for column in colNames:
        if column not in list(matches):
            extraCols.append(column)
        else:
            # Keep all columns from source dataset, adding prefix "src_"
            # if that column name is already in the dataframe
            extraCols.append('src_' + column)
            data.rename(columns={column: 'src_' + column}, inplace=True)
    result = pd.DataFrame(columns=list(matches) + extraCols)
    # Ensure the polarity column contains only strings so the
    # conditional test in the next loop works as expected
    data['Polarity'].replace(np.nan, '', regex=True, inplace=True)
    for index, row in data.iterrows():
        mzMatches = matches.loc[matches['Input Mass'] == row['Input Mass']]
        if row['Polarity'].lower().startswith('n'):
            mzMatches = mzMatches.loc[mzMatches['Adduct'].str[-1] != '+']
        elif row['Polarity'].lower().startswith('p'):
            mzMatches = mzMatches.loc[mzMatches['Adduct'].str[-1] != '-']
        if mzMatches.empty:
            # Unmatched m/z from 'data'
            mzMatches = mzMatches.append(row[['Input Mass', 'rt', 'Polarity']],
                                         ignore_index=True)
        else:
            # Copy RT and polarity values to each matched m/z
            mzMatches['rt'] = row['rt']
            mzMatches['Polarity'] = row['Polarity']
        # Copy the extra columns (if any) to each matched m/z
        for col in extraCols:
            mzMatches[col] = row[col]
        result = result.append(mzMatches, ignore_index=True)
    result.sort_values(['Input Mass', 'Delta_PPM', 'Matched MZ'], inplace=True,
                       kind='mergesort')
    result.rename(columns={"Input Mass": "MS1_MZ", "Delta_PPM": "MASS_DIFF", "Matched MZ": "Lib_mz",
                           "Adduct": "Ion"})
    return result


def align_search(data, param_dct):
    pr_window = param_dct["pr_window"]
    ms1_ppm = param_dct["ms_ppm"]
    lpp_list = data['MS1_MZ'].values
    pr_mz_low = []
    pr_mz_high = []
    ms1_mz_low = []
    ms1_mz_high = []
    for x in lpp_list:
        prmzl = pr_window_calc_para(x, -1 * pr_window)
        pr_mz_low.append(prmzl)
        prmzh = pr_window_calc_para(x,  pr_window)
        pr_mz_high.append(prmzh)
        msmzl = ppm_window_para(x, -1 * ms1_ppm)
        ms1_mz_low.append(msmzl)
        msmzh = ppm_window_para(x, -1 * ms1_ppm)
        ms1_mz_high.append(msmzh)
    data['PR_MZ_LOW'] = pr_mz_low
    data['PR_MZ_HIGH'] = pr_mz_high
    data['MS1_MZ_LOW'] = ms1_mz_low
    data['MS1_MZ_HIGH'] = ms1_mz_high
    return data


def get_fdr(data, parameters):
    mzList = data[parameters['mzCol']].unique().tolist()
    # Set the target adducts
    if parameters['polarity'] == 'Positive':
        targetAdducts = ("M+H,M+H-H2O,M+2H,M+3H,M+4H,M+NH4,M+Ag,M+Na,M+2Na,M+K,"
                         "M+2K,M+Li,M+2Li")
    else:
        targetAdducts = 'M-H,M-CH3,M-2H,M-3H,M-4H,M.F,M.HF2,M.Cl,M.OAc,M.HCOO'
    # Get the number of matches in batches to balance the number of
    # requests and the amount of information requested
    numTargetHits = 0
    numDecoyHits = 0
    for start in range(0, len(mzList), BATCH_SIZE):
        mzBatch = mzList[start: start + BATCH_SIZE]
        # Get a string with one m/z per line (text file alike)
        mzStr = os.linesep.join(map(str, mzBatch))
        numTargetHits += _get_num_matches('COMP_DB', mzStr, targetAdducts)
        numDecoyHits += _get_num_matches('COMP_DB_5', mzStr, targetAdducts)
    # Raise an exception if there are no matches in the target database
    if numTargetHits == 0:
        raise ValueError(("No matches found in the target database. The FDR "
                          "cannot be computed."))
    # FDR = numDecoyHits / numTargetHits
    return float(numDecoyHits) / numTargetHits


def _get_num_matches(db, mzStr, adducts, tolerance=0.001):
    # type: (str, str, str, float) -> int
    """Return the number of matches for the selected database and
    parameters.

    Keyword Arguments:
        db        -- LIPID MAPS' database
        mzStr     -- string with one m/z per line (text file alike)
        adducts   -- list of adducts separated by commas
        tolerance -- mass tolerance in Daltons (+/- to each m/z)
                     [default: 0.001]
    """
    # Create the target data package with the query
    mpData = MultipartEncoder(
        fields={'CHOICE': db, 'ion': adducts,
                'file': ('file', StringIO(mzStr), 'text/plain'),
                'tol': str(tolerance), 'sort': 'DELTA'})
    # Request the table containing the matches from LIPID MAPS
    try:
        response = requests.post(LIPIDMAPS_URL, data=mpData,
                                 headers={'Content-Type': mpData.content_type})
    except:
        raise Exception(("Connection error with the database. Please check your"
                         " network and try again after a few minutes."))
    # Process the response to create a dataframe and count the number of
    # hits (number of m/z that got at least one match in the database)
    if (len(response.text) == 0):
        return 0
    else:
        matches = pd.read_csv(StringIO(response.text), sep='\t',
                              engine='python', index_col=False)
        if (matches.empty):
            return 0
        else:
            return len(matches['Input Mass'].unique())
