import math
import multiprocessing
from multiprocessing import Pool
import time
import csv
import os
from functools import lru_cache
from typing import Iterable, List, NewType, Tuple, Union
import numpy as np
from numpy import int64
import pandas as pd
import configparser
from numba import int32, int64, int16, float32, float64, vectorize
from polytomia.SpectraReader import get_xic_from_pl, extract_mzml
from polytomia.LipidComposer import LipidComposer
from polytomia.PrecursorHunter import PrecursorHunter

SpectrumType = NewType("Spectrum", object)
ReferencesType = QueriesType = Union[List[object], Tuple[object], np.ndarray]
Score = Union[float, Tuple[float, int]]


def get_first_common_element(first: Iterable[str], second: Iterable[str]) -> str:
    return next((item for item in first if item in second), None)


def get_common_keys(first: List[str], second: List[str]) -> List[str]:
    return [value for value in first if value in second or value.lower() in second]


def filter_none(iterable: Iterable) -> Iterable:
    return filter(lambda x: x is not None, iterable)


def save_output(output_path: str, output_df: pd.DataFrame, output_name: str = "output"):
    output_directory = os.path.dirname(output_path)
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    if output_path.endswith(".xlsx"):
        try:
            output_df.to_excel(output_path, index=False)
            print(f"[OUTPUT] ==> Prepare to save {output_name} as: ", output_path)
        except IOError:
            output_df.to_excel(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".xlsx"),
                index=False,
            )
            print(output_path)
    elif output_path.endswith(".csv"):
        try:
            output_df.to_csv(output_path, index=False)
            print(f"[OUTPUT] ==> Prepare to save {output_name} as: ", output_path)
        except IOError:
            output_df.to_csv(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".csv"),
                index=False,
            )
            print(output_path)
    else:
        try:
            output_df.to_excel(f"{output_path}.xlsx", index=False)
            print(
                f"[OUTPUT] ==> Prepare to save {output_name} as: ",
                f"{output_path}.xlsx",
            )
        except IOError:
            output_df.to_excel(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".xlsx"),
                index=False,
            )
            print(output_path)
    print("[OUTPUT] ==> {output_name} saved ...")


@lru_cache(maxsize=4)
def load_known_key_conversions(key_conversions_file: str = None) -> dict:
    if key_conversions_file is None:
        key_conversions_file = os.path.join(os.path.dirname(__file__), "data", "known_key_conversions.csv")
    assert os.path.isfile(key_conversions_file), f"Could not find {key_conversions_file}"

    with open(key_conversions_file, newline='', encoding='utf-8-sig') as csvfile:
        reader = csv.DictReader(csvfile)
        key_conversions = {}
        for row in reader:
            key_conversions[row['known_synonym']] = row['matchms_default']

    return key_conversions


config = configparser.ConfigParser()
config.read("configure.ini")
if config.has_section("settings"):
    user_cfg = "settings"
else:
    if config.has_section("default"):
        user_cfg = "default"
    else:
        user_cfg = ""
if len(user_cfg) > 2:
    options = config.options(user_cfg)

    # numba vectorize issue of target = 'parallel' for PC without CUDA compatible GPU
    if "parallel_target" in options:
        if config.get(user_cfg, "parallel_target") == "CPU":
            para_target = "cpu"
            print("Parallel processing mode -> CPU")
        elif config.get(user_cfg, "parallel_target") in [
            "CPU_and_GPU",
            "GPU",
            "CPUandGPU",
            "CPUGPU",
            "parallel",
        ]:
            para_target = "parallel"
            print("Parallel processing mode -> CPU_and_GPU")
        else:
            para_target = "cpu"
            print("Parallel processing mode -> CPU")
    else:
        para_target = "cpu"
        print("Parallel processing mode -> CPU")

    if "general_mod_lst" in options:
        intensity_factor = float(config.get(user_cfg, "specsim_m"))
    else:
        intensity_factor = 0.6
    if "general_mod_lst" in options:
        mz_factor = float(config.get(user_cfg, "specsim_n"))
    else:
        mz_factor = 0.6
else:
    intensity_factor = 3
    mz_factor = 0.6
    para_target = "cpu"


# print('Weight factor for Similarity score: intensity_factor', intensity_factor, 'mz_factor', mz_factor)


@vectorize(([float64(float64, float64)]), target=para_target)
def pr_window_calc_para(mz, delta):
    return mz + delta


@vectorize(([float64(float64, int64)]), target=para_target)
def ppm_window_para(mz, ppm):
    return mz * (1 + 0.000001 * ppm)


@vectorize(([float64(float64, float64)]), target=para_target)
def ppm_calc_para(mz_obs, mz_lib):
    return 1e6 * (mz_obs - mz_lib) / mz_lib


@vectorize(([float64(float64, float64)]), target=para_target)
def wfactor_calc_para(mz, i):
    return (mz ** mz_factor) * (i ** intensity_factor)


def check_platform(platform, usr_core_num, param_dct):
    if platform == "linux" or platform == "linux2":  # linux
        if usr_core_num > 1:
            os_typ = "linux_multi"
            print(
                "[INFO] --> LipidHunter Running on >>> Linux with multiprocessing mode ..."
            )
        else:
            os_typ = "linux_single"
            print(
                "[INFO] --> LipidHunter Running on >>> Linux with single core mode ..."
            )
    elif platform == "win32":  # Windows
        os_typ = "windows"
        print("[INFO] --> LipidHunter Running on >>> Windows ...")
    elif platform == "darwin":  # macOS
        if usr_core_num > 1:
            os_typ = "linux_multi"
            print(
                "[INFO] --> LipidHunter Running on >>> macOS with multiprocessing mode ..."
            )
        else:
            os_typ = "linux_single"
            print(
                "[INFO] --> LipidHunter Running on >>> macOS with single core mode ..."
            )
    else:
        usr_core_num = 1
        param_dct["core_number"] = 1
        os_typ = "linux_single"
        print(
            "[INFO] --> LipidHunter Running on >>> unoptimized system ... %s" % platform
        )
        print("[WARNING] !!! Force to use single core mode !!")


def normalise_path(path):
    # type: (str) -> str
    """Return a valid path for the current OS.
    Keyword Arguments:
        path -- path to normalize
    """
    return os.path.normpath(os.path.realpath(path))


def traceless_warning(message, category, filename, lineno, file=None,
                      line=None):
    return 'Warning{0}{1}{1}'.format(message, os.linesep)


def mz_delta(mz, fixederr, ppmerr, precision=5):
    # type: (float, float, float, int) -> float
    """Return the delta tolerance for the given m/z.
    Keyword Arguments:
        mz        -- m/z reference value
        fixederr  -- allowed fixed error
        ppmerr    -- mass-dependant PPM error to add to the fixed error
        precision -- number of decimal digits to use with floats (e.g. a
                     precision of 2 forces a difference of 0.01 between
                     two any consecutive float numbers) [default: 5]
    """
    return round(fixederr + (mz * ppmerr * 1e-6), precision)


def mz_tol_range(mz, fixederr, ppmerr, precision=5):
    # type: (float, float, float, int) -> float
    """Return lower and upper tolerance limits for the given m/z.
    Keyword Arguments:
        mz        -- m/z reference value
        fixederr  -- allowed fixed error
        ppmerr    -- mass-dependant PPM error to add to the fixed error
        precision -- number of decimal digits to use with floats (e.g. a
                     precision of 2 forces a difference of 0.01 between
                     two any consecutive float numbers) [default: 5]
    """
    delta = mz_delta(mz, fixederr, ppmerr, precision)
    return round(mz - delta, precision), round(mz + delta, precision)


def rt_delta(maxdiff, precision=5):
    # type: (float, int) -> float
    """Return the delta tolerance for the given retention time.
    Keyword Arguments:
        maxdiff   -- maximum time difference between a feature edge and
                     an adjacent frame to be considered part of the same
                     feature
        precision -- number of decimal digits to use with floats (e.g. a
                     precision of 2 forces a difference of 0.01 between
                     any two consecutive float numbers) [default: 5]
    """
    return round(maxdiff, precision)


def rt_tol_range(rt, maxdiff, precision=5):
    # type: (float, float, int) -> float
    """Return lower and upper tolerance limits for the given retention
    time.
    Keyword Arguments:
        rt        -- retention time (RT) reference value
        maxdiff   -- maximum time difference between a feature edge and
                     an adjacent frame to be considered part of the same
                     feature
        precision -- number of decimal digits to use with floats (e.g. a
                     precision of 2 forces a difference of 0.01 between
                     any two consecutive float numbers) [default: 5]
    """
    delta = rt_delta(maxdiff, precision)
    return (round(rt - delta, precision), round(rt + delta, precision))


def print_progress_bar(iteration, total, prefix='', suffix='Completed',
                       length=34):
    # type: (int, int, str, str, int) -> None
    """Call in a loop to create terminal progress bar.
    Extracted from first answer at: https://stackoverflow.com/questions/
    3173320/text-progress-bar-in-the-console
    Keyword Arguments:
        iteration -- current iteration
        total     -- total iterations
        prefix    -- prefix string [default: no prefix]
        suffix    -- suffix string [default: "Completed"]
        length    -- character length of bar [default: 34]
    """
    percent = "{0:.1f}".format(100 * (iteration / float(total)))
    filledLength = int(length * iteration // total)
    bar = '#' * filledLength + '-' * (length - filledLength)
    print('\r%s |%s| %s%% %s' % (prefix, bar, percent, suffix), end='\r')
    # Print New Line on Complete
    if (iteration == total):
        print()


def save_output(output_path: str, output_df: pd.DataFrame, output_name: str = "output"):
    output_directory = os.path.dirname(output_path)
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)

    if output_path.endswith(".xlsx"):
        try:
            output_df.to_excel(output_path, index=False)
            print(f"[OUTPUT] ==> Prepare to save {output_name} as: ", output_path)
        except IOError:
            output_df.to_excel(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".xlsx"),
                index=False,
            )
            print(output_path)
    elif output_path.endswith(".csv"):
        try:
            output_df.to_csv(output_path, index=False)
            print(f"[OUTPUT] ==> Prepare to save {output_name} as: ", output_path)
        except IOError:
            output_df.to_csv(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".csv"),
                index=False,
            )
            print(output_path)
    else:
        try:
            output_df.to_excel(f"{output_path}.xlsx", index=False)
            print(
                f"[OUTPUT] ==> Prepare to save {output_name} as: ",
                f"{output_path}.xlsx",
            )
        except IOError:
            output_df.to_excel(
                "{0}-{1}{2}".format(output_path[:-5], int(time.time()), ".xlsx"),
                index=False,
            )
            print(output_path)
    print("[OUTPUT] ==> {output_name} saved ...")
