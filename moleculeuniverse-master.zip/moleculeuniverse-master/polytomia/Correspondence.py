import glob
import os

from matchms import calculate_scores
from matchms.similarity import PrecursorMzMatch, IntersectMz, MetadataMatch, ParentMassMatch
from rdkit.Chem.rdRGroupDecomposition import MCS
from rdkit.ML.Cluster import Butina
import pandas as pd
import numpy as np
from sklearn.cluster import DBSCAN
from sklearn import mixture
from scipy.optimize import linear_sum_assignment
from rdkit import Chem, Geometry, DataStructs
from rdkit.Chem import Crippen, rdFingerprintGenerator
from rdkit.Chem import AllChem
from rdkit.Chem import Draw
from copy import deepcopy

from tidyms.metabolomics import _noise_ind


class LDataFrame(pd.DataFrame):

    def __init__(self, src, resolution=6):

        if not os.path.isdir(src):
            data = self._read_file(src)
        else:
            # Create a list of the input files in the source folder (in
            # alphabetical order)
            fileList = sorted(glob.iglob(os.path.join(src, '*.*')))
            if len(fileList) == 0:
                raise FileNotFoundError("No files found in '{0}'".format(src))
            data = self._read_file(fileList[0])
            if len(fileList) > 1:
                # Sort first dataframe by RT
                data.sort_values(['rt'], inplace=True, kind='mergesort')
                timeCol = 'minute'
                data = data.assign(minute=data['rt'].astype(int))
                data = data[data[timeCol] != data.iloc[-1][timeCol]]
                for index, filePath in enumerate(fileList[1:], start=1):
                    chunk = self._read_file(filePath)
                    # Sort next chunk dataframe by RT
                    chunk.sort_values(['mz'], inplace=True, kind='mergesort')
                    # Append "minute" column to the dataframe with the
                    # integer part of the float values of its RT column
                    chunk = chunk.assign(minute=chunk['rt'].astype(int))
                    # Remove the frames of the first minute
                    chunk = chunk[chunk[timeCol] != chunk.iloc[0][timeCol]]
                    if index < (len(fileList) - 1):
                        chunk = chunk[chunk[timeCol] != chunk.iloc[-1][timeCol]]
                    overlap = pd.DataFrame(
                        {'data': data.groupby(timeCol).size(),
                         'chunk': chunk.groupby(timeCol).size()}
                    ).fillna(0)
                    # Keep the minutes where the number of frames in the
                    # next chunk is higher than in the current dataframe
                    overlap = overlap[overlap['chunk'] > overlap['data']]
                    minutesToReplace = overlap.index.tolist()
                    if minutesToReplace:
                        # Remove the dataframe frames to be replaced
                        data = data[~data[timeCol].isin(minutesToReplace)]
                        # Append chunk frames preserving the column
                        # order of the main dataframe
                        data = data.append(
                            chunk[chunk[timeCol].isin(minutesToReplace)],
                            ignore_index=True
                        )[data.columns.tolist()]
                # Drop "minute" column as it will be no longer necessary

        # Rename first column if no name was given in the input file(s)
        data.rename(columns={'Unnamed: 0': 'id'}, inplace=True)
        data.sort_values(['mz', 'rt'], inplace=True, kind='mergesort')
        data.reset_index(drop=True, inplace=True)
        # Adjust m/z column values to the machine's maximum float
        # resolution
        data['mz'] = data['mz'].apply(round, ndigits=resolution)
        super(LDataFrame, self).__init__(data=data)
        self.src = src
        self._resolution = resolution

    def drop_empty_frames(self, module, parameters, means=False):
        """Remove empty frames from the dataframe and reset the index.
        An empty frame is a row for which every sample replicate or
        sample mean has a zero intensity.
        Keyword Arguments:
            module     -- module name to write in the logging file
            parameters -- LipidFinder's parameters instance (can be for
                          any module)
            means      -- check sample means instead of each sample
                          replicate? [default: False]
        """
        if means:
            meanColIndexes = [i for i, col in enumerate(self.columns)
                              if col.endswith('_mean')]
            if parameters['numSolventReps'] > 0:
                # The first mean column is for the solvents
                firstIndex = meanColIndexes[1]
            else:
                firstIndex = meanColIndexes[0]
            lastIndex = meanColIndexes[-1] + 1
        else:
            firstIndex = parameters['firstSampleIndex'] - 1
            lastIndex = firstIndex + (parameters['numSamples'] * parameters['numTechReps'])
        # Get the indices of all empty frames
        emptyFrames = self.iloc[:, firstIndex: lastIndex].eq(0).all(axis=1)
        indices = self[emptyFrames].index.tolist()
        if indices:
            # Drop empty frames and reset the index
            self.drop(module, labels=indices, axis=0, inplace=True)
            self.reset_index(drop=True, inplace=True)

    @staticmethod
    def _read_file(src):
        extension = os.path.splitext(src)[1].lower()[1:]
        # Load file based on its extension
        if extension == 'tab':
            data = pd.read_csv(src, sep='\t', float_precision='high')
        elif extension == 'tsv':
            data = pd.read_csv(src, sep='\t', float_precision='high')
        else:
            raise IOError(("Unknown file extension '{0}'. Expected: csv, tsv, "
                           "xls, xlsx").format(extension))

        data['rt'] = data['rt'].apply(lambda x: round(x / 60.0, 2))
        return data


def feature_correspondence(feature_data: pd.DataFrame, mz_tolerance: float,
                           rt_tolerance: float, min_fraction: float = 0.2,
                           min_likelihood: float = 0.0):
    sample_names = feature_data["sample"].unique()

    # DBSCAN clustering
    min_samples = int(sample_names.size * min_fraction + 1)
    cluster = _make_initial_cluster(feature_data, mz_tolerance, rt_tolerance,
                                    min_samples)
    data = feature_data[cluster != -1]
    noise = feature_data[cluster == -1]
    cluster = cluster.astype(str)
    features_per_cluster = _estimate_n_species_per_cluster(data, cluster)

    for name, group in data.groupby(cluster):
        n_ft = features_per_cluster[name]
        subcluster = _process_cluster(group, noise, cluster, sample_names, name,
                                      n_species=n_ft,
                                      min_likelihood=min_likelihood)
        cluster[subcluster.index] = subcluster
    cluster_value = np.sort(cluster.unique())
    n_cluster = cluster_value.size
    has_noise = "-1" in cluster_value
    # set a feature code for each feature
    if has_noise:
        cluster_names = _make_feature_names(n_cluster - 1)
        cluster_names = ["noise"] + cluster_names
    else:
        cluster_names = _make_feature_names(n_cluster)

    cluster_mapping = dict(zip(cluster_value, cluster_names))
    cluster = cluster.map(cluster_mapping)
    return cluster


def _make_feature_names(n_features: int):
    max_ft_str_length = len(str(n_features))

    def ft_formatter(x):
        return "FT" + str(x + 1).rjust(max_ft_str_length, "0")

    ft_names = [ft_formatter(x) for x in range(n_features)]
    return ft_names


def _flatten_column_multindex(df: pd.DataFrame):
    columns = df.columns
    level_0 = columns.get_level_values(0)
    level_1 = columns.get_level_values(1)
    col_name_map = {"mzmean": "mz", "mzstd": "mz std", "mzmin": "mz min",
                    "mzmax": "mz max", "rtmean": "rt", "rtstd": "rt std",
                    "rtmin": "rt min", "rtmax": "rt max"}
    new_names = [col_name_map[x + y] for x, y in zip(level_0, level_1)]
    return new_names


def _make_initial_cluster(feature_data: pd.DataFrame, mz_tolerance: float,
                          rt_tolerance: float, min_samples: int = 8):
    """
    First guess of correspondence between features using DBSCAN algorithm.
    Auxiliary function to feature_correspondence.
    Parameters
    ----------
    feature_data : DataFrame
        DataFrame obtained from `detect_features` function.
    mz_tolerance : float
        Used to build epsilon parameter of DBSCAN
    rt_tolerance : float
        Used to build epsilon parameter of DBSCAN.
    min_samples : int
        parameter to pass to DBSCAN
    Returns
    -------
    cluster : Series
        The assigned cluster by DBSCAN
    """

    ft_points = feature_data.loc[:, ["mz", "rt"]].copy()
    ft_points["rt"] = ft_points["rt"] * mz_tolerance / rt_tolerance
    dbscan = DBSCAN(eps=mz_tolerance, min_samples=min_samples,
                    metric="chebyshev")
    dbscan.fit(ft_points)
    cluster = pd.Series(data=dbscan.labels_, index=feature_data.index)
    return cluster


def _estimate_n_species_per_cluster(df: pd.DataFrame, cluster: pd.Series,
                                    min_dr: float = 0.2):
    """
    Estimates the number of features that forms a cluster.
    The number of features is estimated as follows:
        1. The number of features per sample is counted and normalized
        to the total number of features.
        2. The number of features in a cluster will be the maximum
        normalized number of features per sample greater than the minimum
        detection rate.
    Parameters
    ----------
    df: DataFrame
        Feature data obtained from feature_correspondence function
    min_dr: float, 0.2
        Minimum detection rate.
    """

    # sample_per_cluster counts the number of features that come from the same
    # sample and express it as a fraction of the total number features
    # the number of features in a cluster is the maximum number of samples
    # in a cluster above the minimum detection rate.

    def find_n_cluster(x):
        return x.index[np.where(x > min_dr)[0]][-1]

    sample_per_cluster = (df["sample"].groupby(cluster)
                          .value_counts()
                          .unstack(-1)
                          .fillna(0)
                          .astype(int)
                          .apply(lambda x: x.value_counts(), axis=1)
                          .fillna(0))
    sample_per_cluster = sample_per_cluster / df["sample"].unique().size

    features_per_cluster = sample_per_cluster.apply(find_n_cluster, axis=1)
    return features_per_cluster


def _make_gmm(ft_data: pd.DataFrame, n_feature: int, cluster_name: str):
    """
    fit a gaussian model and set subcluster names for each feature. Auxiliary
    function to process cluster.
    Parameters
    ----------
    ft_data : DataFrame
        The mz and rt columns of the cluster DataFrame
    n_feature : int
        Number of features estimated in the cluster.
    cluster_name: str
    Returns
    -------
    gmm : GaussianMixtureModel fitted with cluster data
    score: The log-likelihood of each feature.
    subcluster : pd.Series with subcluster labels.
    """
    gmm = mixture.GaussianMixture(n_components=n_feature,
                                  covariance_type="diag")
    gmm.fit(ft_data.loc[:, ["mz", "rt"]].values)
    # scores = pd.Series(data=gmm.score_samples(ft_data), index=ft_data.index)
    ft_data["score"] = gmm.score_samples(ft_data.loc[:, ["mz", "rt"]].values)

    # get index of features in the cases where the number of features is greater
    # than the number of components in the gmm
    noise_index = (ft_data
                   .groupby("sample")
                   .filter(lambda x: x.shape[0] > n_feature))

    if not noise_index.empty:
        noise_index = (noise_index
                       .groupby("sample")
                       .apply(lambda x: _noise_ind(x, n_feature))
                       .droplevel(0)
                       .index)
    else:
        noise_index = noise_index.index

    noise = pd.Series(data="-1", index=noise_index)

    # if the number of features is equal to the number of components in the
    # gmm, each feature is assigned to a cluster using the Hungarian algorithm
    # on the posterior probabilities on each component
    subcluster = (ft_data.loc[ft_data.index.difference(noise_index)]
                  .groupby("sample")
                  .filter(lambda x: x.shape[0] <= n_feature)
                  .groupby("sample")
                  .apply(lambda x: _get_best_cluster(x, gmm))
                  .droplevel(0)
                  .astype(str))
    subcluster = subcluster.apply(lambda x: str(cluster_name) + "-" + x)
    subcluster = pd.concat([noise, subcluster])
    subcluster = subcluster.sort_index()
    # TODO: add here the case where n_features < n_components

    # subcluster = pd.Series(data=gmm.predict(ft_data), index=ft_data.index,
    #                        dtype=str)
    scores = 1
    return gmm, scores, subcluster


def _process_cluster(df: pd.DataFrame, noise: pd.DataFrame, cluster: pd.Series,
                     sample_names: list, cluster_name: str,
                     min_likelihood: float, n_species: int):
    """
    Process each cluster obtained from DBSCAN. Auxiliary function to
    `feature_correspondence`.
    Parameters
    ----------
    df : DataFrame
        feature_data values for a given cluster
    noise : DataFrame
        Features flagged as noise by DBSCAN
    cluster : Series
        Cluster values obtained by DBSCAN.
    sample_names : list[str]
        names of the analyzed samples.
    cluster_name : str
        name of the cluster being analyzed
    min_likelihood : float
    n_species: int
        Number of features in the cluster, estimated with
        `estimate_features_per_cluster`.
    Returns
    -------
    subcluster : Series
        The subcluster values.
    """

    ft_data = df.loc[:, ["mz", "rt", "sample"]]
    sample_data = df["sample"]

    if n_species >= 1:
        # fit a Gaussian mixture model using the cluster data
        gmm, scores, subcluster = _make_gmm(ft_data, n_species, cluster_name)
    else:
        subcluster = pd.Series(data="-1", index=df.index)

    # send repeated samples to noise: only the feature with the best
    # score in the subcluster is conserved
    # _remove_repeated_features(ft_data, subcluster, sample_data, scores)

    to_noise = df[subcluster == "-1"]
    if not to_noise.empty:
        noise = pd.concat([noise, to_noise])

    # search missing samples in noise:
    # _search_missing_features(cluster, sample_data, n_species, cluster_name,
    #                          sample_names, noise, subcluster, gmm,
    #                          min_likelihood)
    return subcluster


def _get_best_cluster(x, gmm):
    """
    Assigns a feature to a cluster the posterior probability to each cluster.
    """
    proba = gmm.predict_proba(x.loc[:, ["mz", "rt"]].values)
    rows, cols = proba.shape
    if rows != cols:
        fill = np.zeros(shape=(cols - rows, cols))
        proba = np.vstack((proba, fill))
    _, best_cluster = linear_sum_assignment(proba)
    best_cluster = best_cluster[:rows]
    best_cluster = pd.Series(data=best_cluster, index=x.index)
    return best_cluster


def highlight_molecules(molecules, mcs, number, label=True, same_orientation=True, **kwargs):
    """Highlight the MCS in our query molecules"""
    molecules = deepcopy(molecules)
    # convert MCS to molecule
    pattern = Chem.MolFromSmarts(mcs.smartsString)
    # find the matching atoms in each molecule
    matching = [molecule.GetSubstructMatch(pattern) for molecule in molecules[:number]]

    legends = None
    if label is True:
        legends = [x.GetProp("_Name") for x in molecules]

    # Align by matched substructure so they are depicted in the same orientation
    # Adapted from: https://gist.github.com/greglandrum/82d9a86acb3b00d3bb1df502779a5810
    if same_orientation:
        mol, match = molecules[0], matching[0]
        AllChem.Compute2DCoords(mol)
        coords = [mol.GetConformer().GetAtomPosition(x) for x in match]
        coords2D = [Geometry.Point2D(pt.x, pt.y) for pt in coords]
        for mol, match in zip(molecules[1:number], matching[1:number]):
            if not match:
                continue
            coord_dict = {match[i]: coord for i, coord in enumerate(coords2D)}
            AllChem.Compute2DCoords(mol, coordMap=coord_dict)

    return Draw.MolsToGridImage(
        molecules[:number],
        legends=legends,
        molsPerRow=5,
        highlightAtomLists=matching[:number],
        subImgSize=(200, 200),
        **kwargs,
    )


def compound_clustering(smiles_list):
    mols_list = []
    for x in smiles_list:
        m = Chem.MolFromSmiles(x)
        mols_list.append(m)
    fps = []
    for y in mols_list:
        fps.append(Chem.RDKFingerprint(y, maxPath=5))
    # generate distance matrix
    dist_matrix = []
    num_fps = len(fps)
    for i in range(1, num_fps):
        similarities = DataStructs.BulkTanimotoSimilarity(fps[i], fps[:i])
        dist_matrix.extend([1 - x for x in similarities])
    # cluster
    clusters = Butina.ClusterData(dist_matrix, num_fps, 0.5, isDistData=True)  # distance cutoff = 0.5
    print("number of clusters =", len(clusters))
    num_clust_g5 = len([c for c in clusters if len(c) > 5])
    print("number of clusters with more than 5 compounds =", num_clust_g5)

    # Create fingerprints for all molecules
    rdkit_gen = rdFingerprintGenerator.GetRDKitFPGenerator(maxPath=5)
    fingerprints = [rdkit_gen.GetFingerprint(mol) for mol in mols_list]

    def tanimoto_distance_matrix(fp_list):
        """Calculate distance matrix for fingerprint list"""
        dissimilarity_matrix = []
        # Notice how we are deliberately skipping the first and last items in the list
        # because we don't need to compare them against themselves
        for i in range(1, len(fp_list)):
            # Compare the current fingerprint against all the previous ones in the list
            similarities = DataStructs.BulkTanimotoSimilarity(fp_list[i], fp_list[:i])
            # Since we need a distance matrix, calculate 1-x for every element in similarity matrix
            dissimilarity_matrix.extend([1 - x for x in similarities])
        return dissimilarity_matrix

    distance_matrix = tanimoto_distance_matrix(fingerprints)

    def cluster_fingerprints(fingerprints, cutoff=0.2):
        """Cluster fingerprints
        Parameters:
            fingerprints
            cutoff: threshold for the clustering
        """
        # Calculate Tanimoto distance matrix
        distance_matrix = tanimoto_distance_matrix(fingerprints)
        # Now cluster the data with the implemented Butina algorithm:
        clusters = Butina.ClusterData(distance_matrix, len(fingerprints), cutoff, isDistData=True)
        clusters = sorted(clusters, key=len, reverse=True)
        return clusters

    clusters = cluster_fingerprints(fingerprints, cutoff=0.3)

    def partition_coefficient(mols_list):
        new_mols = []
        bad_mols = []
        for m, idx in mols_list:
            logp = Crippen.MolLogP(m)
            if logp < -5 or logp > 7.5:
                bad_mols.append((m, idx))
            else:
                new_mols.append((m, idx))
        mols = new_mols

    def compound_selection(clusters):
        final_mols = [mols_list[c[0]] for c in clusters]
        # sort the molecules within a cluster based on their similarity
        # to the cluster centre and sort the clusters based on their size
        clusters2 = []
        for c in clusters:
            if len(c) < 2: continue
            fps_clust = [Chem.RDKFingerprint(mols_list[i][0], maxPath=5) for i in c]
            simils = DataStructs.BulkTanimotoSimilarity(fps_clust[0],
                                                        fps_clust[1:])
            simils = [(s, i) for s, i in zip(simils, c[1:])]
            simils.sort(reverse=True)
            clusters2.append((len(simils), [i for s, i in simils]))
        clusters2.sort(reverse=True)

        # take 5 molecules (or 50%) of each cluster starting with the
        # largest one
        idx = 0
        diff = 500 - len(final_mols)
        while diff > 0:
            c = clusters2[idx][1]
            if clusters2[idx][0] > 5:
                num_cmps = 5
            else:
                num_cmps = int(0.5 * len(c)) + 1
            if num_cmps > diff: num_cmps = diff
            final_mols += [mols_list[i] for i in c[:num_cmps]]
            idx += 1
            diff = 500 - len(final_mols)
        print("number of selected molecules =", len(final_mols))

        num_clust = len(clusters)
        mols_cluster0 = [final_mols[0]] + final_mols[num_clust:num_clust + 5]
        mcs = MCS.FindMCS([m[0] for m in mols_cluster0])  # get scaffold
        scaffold = Chem.MolFromSmarts(mcs.smarts)
        AllChem.Compute2DCoords(scaffold)  # generate 2D coordinates for scaffold
        for m, idx in mols_cluster0:  # align molecules to scaffold
            AllChem.GenerateDepictionMatching2DStructure(m, scaffold)
        Draw.MolsToGridImage([m[0] for m in mols_cluster0],
                             legends=[m[1] for m in mols_cluster0],
                             molsPerRow=4)


def mass_filter(spectrums):
    references = [spectrums]
    queries = [spectrums]
    similarity_score = PrecursorMzMatch(tolerance=5.0, tolerance_type="Dalton")
    scores = calculate_scores(references, queries, similarity_score)
    similarity_score = PrecursorMzMatch(tolerance=5.0, tolerance_type="Dalton")
    scores = calculate_scores(references, queries, similarity_score)
    for (reference, query, score) in scores:
        print(f"Precursor m/z match between {reference.get('id')} and {query.get('id')}" +
              f" is {score:.2f}")
    similarity_measure = IntersectMz(scaling=1.0)
    score = similarity_measure.pair(references, queries)
    print(f"IntersectMz score is {score:.2f}")
    similarity_score = MetadataMatch(field="instrument_type")
    scores = calculate_scores(references, queries, similarity_score)
    for (reference, query, score) in scores:
        print(f"Metadata match between {reference.get('id')} and {query.get('id')}" + f" is {score:.2f}")
    similarity_score = ParentMassMatch(tolerance=5.0)
    scores = calculate_scores(references, queries, similarity_score)
    for (reference, query, score) in scores:
        print(f"Parentmass match between {reference.get('id')} and {query.get('id')}" +
              f" is {score:.2f}")
