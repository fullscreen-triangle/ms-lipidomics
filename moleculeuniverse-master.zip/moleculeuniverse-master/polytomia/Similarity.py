from typing import List, Tuple, Optional
import numba
import numpy as np
import networkx as nx
from matchms import Scores
from matchms.similarity import ModifiedCosine
from matchms.similarity.BaseSimilarity import BaseSimilarity
from matchms.typing import ReferencesType, QueriesType
import itertools
import gzip
import rdkit.Chem
import rdkit.Chem.AllChem
import rdkit.DataStructs
from polytomia.Networks import get_top_hits


@numba.njit
def collect_peak_pairs(spec1: np.ndarray, spec2: np.ndarray,
                       tolerance: float, shift: float = 0, mz_power: float = 0.0,
                       intensity_power: float = 1.0):
    # pylint: disable=too-many-arguments
    """Find matching pairs between two spectra.

    Args
    ----
    spec1:
        Spectrum peaks and intensities as np array.
    spec2:
        Spectrum peaks and intensities as np array.
    tolerance
        Peaks will be considered a match when <= tolerance appart.
    shift
        Shift spectra peaks by shift. The default is 0.
    mz_power:
        The power to raise mz to in the cosine function. The default is 0, in which
        case the peak intensity products will not depend on the m/z ratios.
    intensity_power:
        The power to raise intensity to in the cosine function. The default is 1.

    Returns
    -------
    matching_pairs : np array
        Array of found matching peaks.
    """
    matches = find_matches(spec1[:, 0], spec2[:, 0], tolerance, shift)
    idx1 = [x[0] for x in matches]
    idx2 = [x[1] for x in matches]
    if len(idx1) == 0:
        return None
    matching_pairs = []
    for i, idx in enumerate(idx1):
        power_prod_spec1 = (spec1[idx, 0] ** mz_power) * (spec1[idx, 1] ** intensity_power)
        power_prod_spec2 = (spec2[idx2[i], 0] ** mz_power) * (spec2[idx2[i], 1] ** intensity_power)
        matching_pairs.append([idx1[i], idx2[i], power_prod_spec1 * power_prod_spec2])
    return np.array(matching_pairs.copy())


@numba.njit
def find_matches(spec1_mz: np.ndarray, spec2_mz: np.ndarray,
                 tolerance: float, shift: float = 0) -> List[Tuple[int, int]]:
    """Faster search for matching peaks.
    Makes use of the fact that spec1 and spec2 contain ordered peak m/z (from
    low to high m/z).

    Parameters
    ----------
    spec1_mz:
        Spectrum peak m/z values as np array. Peak mz values must be ordered.
    spec2_mz:
        Spectrum peak m/z values as np array. Peak mz values must be ordered.
    tolerance
        Peaks will be considered a match when <= tolerance appart.
    shift
        Shift peaks of second spectra by shift. The default is 0.

    Returns
    -------
    matches
        List containing entries of type (idx1, idx2).

    """
    lowest_idx = 0
    matches = []
    for peak1_idx in range(spec1_mz.shape[0]):
        mz = spec1_mz[peak1_idx]
        low_bound = mz - tolerance
        high_bound = mz + tolerance
        for peak2_idx in range(lowest_idx, spec2_mz.shape[0]):
            mz2 = spec2_mz[peak2_idx] + shift
            if mz2 > high_bound:
                break
            if mz2 < low_bound:
                lowest_idx = peak2_idx
            else:
                matches.append((peak1_idx, peak2_idx))
    return matches


@numba.njit(fastmath=True)
def score_best_matches(matching_pairs: np.ndarray, spec1: np.ndarray,
                       spec2: np.ndarray, mz_power: float = 0.0,
                       intensity_power: float = 1.0) -> Tuple[float, int]:
    """Calculate cosine-like score by multiplying matches. Does require a sorted
    list of matching peaks (sorted by intensity product)."""
    score = float(0.0)
    used_matches = int(0)
    used1 = set()
    used2 = set()
    for i in range(matching_pairs.shape[0]):
        if not matching_pairs[i, 0] in used1 and not matching_pairs[i, 1] in used2:
            score += matching_pairs[i, 2]
            used1.add(matching_pairs[i, 0])  # Every peak can only be paired once
            used2.add(matching_pairs[i, 1])  # Every peak can only be paired once
            used_matches += 1

    # Normalize score:
    spec1_power = spec1[:, 0] ** mz_power * spec1[:, 1] ** intensity_power
    spec2_power = spec2[:, 0] ** mz_power * spec2[:, 1] ** intensity_power

    score = score / (np.sum(spec1_power ** 2) ** 0.5 * np.sum(spec2_power ** 2) ** 0.5)
    return score, used_matches


def calculate_vector_scores(references: ReferencesType, queries: QueriesType, similarity_function: BaseSimilarity,
                            is_symmetric: bool = False, ):
    return Scores(references=references, queries=queries,
                  similarity_function=similarity_function,
                  is_symmetric=is_symmetric).calculate()


def calculate_scores(references: ReferencesType, queries: QueriesType,
                     similarity_function: BaseSimilarity, is_symmetric: bool = False, ):
    return Scores(references=references, queries=queries,
                  similarity_function=similarity_function,
                  is_symmetric=is_symmetric).calculate()


class SimilarityNetwork:

    def __init__(self, identifier_key: str = "spectrum_id",
                 top_n: int = 20,
                 max_links: int = 10,
                 score_cutoff: float = 0.7,
                 link_method: str = 'single',
                 keep_unconnected_nodes: bool = True):
        """
        Parameters
        ----------
        identifier_key
            Metadata key for unique intentifier for each spectrum in scores.
            Will also be used for the naming the network nodes. Default is 'spectrum_id'.
        top_n
            Consider edge between spectrumA and spectrumB if score falls into
            top_n for spectrumA or spectrumB (link_method="single"), or into
            top_n for spectrumA and spectrumB (link_method="mutual"). From those
            potential links, only max_links will be kept, so top_n must be >= max_links.
        max_links
            Maximum number of links to add per node. Default = 10.
            Due to incoming links, total number of links per node can be higher.
            The links are populated by looping over the query spectrums.
            Important side note: The max_links restriction is strict which means that
            if scores around max_links are equal still only max_links will be added
            which can results in some random variations (sorting spectra with equal
            scores restuls in a random order of such elements).
        score_cutoff
            Threshold for given similarities. Edges/Links will only be made for
            similarities > score_cutoff. Default = 0.7.
        link_method
            Chose between 'single' and 'mutual'. 'single will add all links based
            on individual nodes. 'mutual' will only add links if that link appears
            in the given top-n list for both nodes.
        keep_unconnected_nodes
            If set to True (default) all spectra will be included as nodes even
            if they have no connections/edges of other spectra. If set to False
            all nodes without connections will be removed.
        """
        # pylint: disable=too-many-arguments
        self.identifier_key = identifier_key
        self.top_n = top_n
        self.max_links = max_links
        self.score_cutoff = score_cutoff
        self.link_method = link_method
        self.keep_unconnected_nodes = keep_unconnected_nodes
        self.graph: Optional[nx.Graph] = None
        """NetworkX graph. Set after calling create_network()"""

    @staticmethod
    def _select_edge_score(similars_scores: dict, scores_type: np.dtype):
        """Chose one value if score contains multiple values (e.g. "score" and "matches")"""
        if len(scores_type) > 1 and "score" in scores_type.names:
            return {key: value["score"] for key, value in similars_scores.items()}
        if len(scores_type) > 1:  # Assume that first entry is desired score
            return {key: value[0] for key, value in similars_scores.items()}
        return similars_scores

    def create_network(self, scores: Scores):
        """
        Function to create network from given top-n similarity values. Expects that
        similarities given in scores are from an all-vs-all comparison including all
        possible pairs.

        Parameters
        ----------
        scores
            Matchms Scores object containing all spectrums and pair similarities for
            generating a network.
        """
        assert self.top_n >= self.max_links, "top_n must be >= max_links"
        assert np.all(scores.queries == scores.references), \
            "Expected symmetric scores object with queries==references"
        unique_ids = list({s.get(self.identifier_key) for s in scores.queries})

        # Initialize network graph, add nodes
        msnet = nx.Graph()
        msnet.add_nodes_from(unique_ids)

        # Collect location and score of highest scoring candidates for queries and references
        similars_idx, similars_scores = get_top_hits(scores, identifier_key=self.identifier_key,
                                                     top_n=self.top_n,
                                                     search_by="queries",
                                                     ignore_diagonal=True)
        similars_scores = self._select_edge_score(similars_scores, scores.scores.dtype)

        # Add edges based on global threshold (cutoff) for weights
        for i, spec in enumerate(scores.queries):
            query_id = spec.get(self.identifier_key)

            ref_candidates = np.array([scores.references[x].get(self.identifier_key)
                                       for x in similars_idx[query_id]])
            idx = np.where((similars_scores[query_id] >= self.score_cutoff) &
                           (ref_candidates != query_id))[0][:self.max_links]
            if self.link_method == "single":
                new_edges = [(query_id, str(ref_candidates[x]),
                              float(similars_scores[query_id][x])) for x in idx]
            elif self.link_method == "mutual":
                new_edges = [(query_id, str(ref_candidates[x]),
                              float(similars_scores[query_id][x]))
                             for x in idx if i in similars_idx[ref_candidates[x]][:]]
            else:
                raise ValueError("Link method not kown")

            msnet.add_weighted_edges_from(new_edges)

        if not self.keep_unconnected_nodes:
            msnet.remove_nodes_from(list(nx.isolates(msnet)))
        self.graph = msnet

    def export_to_graphml(self, filename: str):
        """Save the network as .graphml file.

        Parameters
        ----------
        filename
            Specify filename for exporting the graph.

        """
        if not self.graph:
            raise ValueError("No network found. Make sure to first run .create_network() step")
        nx.write_graphml_lxml(self.graph, filename)


def calculate_network(spectrums, meta_tag):
    modified_cosine = ModifiedCosine(tolerance=0.2)
    scores = calculate_scores(spectrums, spectrums, modified_cosine)
    ms_network = SimilarityNetwork(identifier_key=meta_tag)
    ms_network.create_network(scores)

    nodes = list(ms_network.graph.nodes())
    nodes.sort()
    return nodes

